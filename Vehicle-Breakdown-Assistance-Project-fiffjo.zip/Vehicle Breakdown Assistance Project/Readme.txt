How to run the Vehicle Breakdown Assistance Management System Using PHP and MySQL
1. Download the  zip file
2. Extract the file and copy vehicleassitancems folder
3. Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name vehassitancemsdb
6. Import vehassitancemsdb.sql file(given inside the zip package in SQL file folder)
7. Run the script http://localhost/vehicleassitancems (frontend)

Credential for admin panel :
Username: admin
Password: Test@123

Credential for Driver panel :
Username: test123
Password: Test@123

For user you can raise a request.